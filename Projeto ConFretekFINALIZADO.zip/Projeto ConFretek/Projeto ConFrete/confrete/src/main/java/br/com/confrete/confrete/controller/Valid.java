package br.com.confrete.confrete.controller;

public @interface Valid {

}
