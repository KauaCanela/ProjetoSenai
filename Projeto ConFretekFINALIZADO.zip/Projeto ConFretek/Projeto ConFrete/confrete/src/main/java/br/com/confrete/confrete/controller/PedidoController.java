package br.com.confrete.confrete.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.confrete.confrete.DAO.IPedido;
import br.com.confrete.confrete.DAO.IUsuario;
import br.com.confrete.confrete.DAO.IUsuariocl;
import br.com.confrete.confrete.DAO.PedidoRepository;
import br.com.confrete.confrete.model.Pedido;
import br.com.confrete.confrete.model.Usuario;
import br.com.confrete.confrete.model.UsuarioCl;

@RestController
@RequestMapping("/pedidos")
@CrossOrigin(origins = "*")
public class PedidoController {

    @Autowired
    private IPedido pedidoRepository;
    @Autowired
    private IUsuario usuarioRepository;
    @Autowired
    private PedidoRepository pedidosRepository;
    @Autowired
    private IUsuariocl usuarioClRepository;

    // Método para listar todos os pedidos
    @GetMapping("/{id}")
    public ResponseEntity<Pedido> buscarPedidoPorId(@PathVariable Integer id) {
        Optional<Pedido> pedido = pedidoRepository.findById(id);
        return pedido.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Método para buscar todos os pedidos
    @GetMapping("/todospdd")
    public ResponseEntity<List<Pedido>> buscarTodosPedidos() {
        List<Pedido> pedidos = pedidoRepository.findAll();
        if (pedidos.isEmpty()) {
            return ResponseEntity.noContent().build(); // Retorna 204 se a lista estiver vazia
        }
        return ResponseEntity.ok(pedidos); // Retorna a lista de pedidos com status 200
    }

    // Método para buscar pedidos por ID do cliente
    @GetMapping("/por-cliente/{idCliente}")
    public ResponseEntity<List<Pedido>> obterPedidosPorCliente(@PathVariable Integer idCliente) {
        List<Pedido> pedidos = pedidosRepository.findByClienteId(idCliente); // Consulta com chave estrangeira
        if (pedidos.isEmpty()) {
            return ResponseEntity.notFound().build(); // Retorna 404 se não houver pedidos
        }
        return ResponseEntity.ok(pedidos); // Retorna os pedidos com status 200
    }

    // Método para criar um novo pedido
    
  


    // Método para listar pedidos pendentes (sem transportador)
    @GetMapping("/pendentes")
    public List<Pedido> listarPedidosPendentes() {
        return pedidosRepository.findByTransportadorIsNull(); // Retorna pedidos onde transportador é null
    }
    
    @GetMapping("/pedidos/{idTr}")
    public List<Pedido> getPedidosByTransportadorId(@PathVariable Integer idTr) {
        return pedidosRepository.findByTransportadorId(idTr); // Método que encontra os pedidos do transportador
    }

    
    @GetMapping("/atribuidos/{idTransportador}")
    public List<Pedido> buscarPedidosAceitos(@PathVariable Integer idTransportador) {
        return pedidosRepository.findByTransportadorId(idTransportador);
    }
    
    @GetMapping("/clientes/{id}")
    public ResponseEntity<UsuarioCl> buscarClientePorId(@PathVariable Integer id) {
        Optional<UsuarioCl> cliente = usuarioClRepository.findById(id);
        return cliente.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
    
    @PostMapping("/cadastrar")
    public ResponseEntity<Pedido> cadastrarPedido(@RequestBody Pedido pedido) {
        if (pedido.getStatus() == null || pedido.getStatus().isEmpty()) {
            pedido.setStatus("Pendente"); // Definir valor padrão se o status não for enviado
        }
        Pedido pedidoSalvo = pedidoRepository.save(pedido);
        return new ResponseEntity<>(pedidoSalvo, HttpStatus.CREATED);
    }


    
    

    
   @PutMapping("/atualizar/{id}")
    public ResponseEntity<Pedido> atualizarStatusPedido(@PathVariable Integer id, @RequestBody String status) {
        Pedido pedido = pedidoRepository.findById(id).orElse(null);
        if (pedido != null) {
            pedido.setStatus(status);  // Atualiza o status do pedido
            pedidoRepository.save(pedido);  // Salva o pedido atualizado no banco
            return ResponseEntity.ok(pedido);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    // Método para aceitar pedido e associar o transportador
    @PutMapping("/{id}")
    public ResponseEntity<Pedido> aceitarPedido(@PathVariable Integer id, @RequestBody Integer idTransportador) {
        Pedido pedido = pedidoRepository.findById(id).orElseThrow(() -> new RuntimeException("Pedido não encontrado"));

        // Buscando o transportador pelo ID
        Usuario transportador = usuarioRepository.findById(idTransportador)
                .orElseThrow(() -> new RuntimeException("Transportador não encontrado"));

        pedido.setTransportador(transportador);
        Pedido pedidoAtualizado = pedidoRepository.save(pedido);

        return ResponseEntity.ok(pedidoAtualizado);
    }

    // Método para atualizar o transportador no pedido
    @PutMapping("/{id}/atualizar-transportador")
    public ResponseEntity<Pedido> atualizarTransportador(@PathVariable Integer id, @RequestBody Map<String, Integer> payload) {
        Integer idTransportador = payload.get("idTransportador"); // Obtém o ID do transportador do JSON
        Optional<Pedido> pedidoExistente = pedidoRepository.findById(id);

        if (pedidoExistente.isPresent()) {
            Pedido pedidoAtualizado = pedidoExistente.get();

            Optional<Usuario> transportadorOptional = usuarioRepository.findById(idTransportador);
            if (transportadorOptional.isPresent()) {
                Usuario transportador = transportadorOptional.get();
                pedidoAtualizado.setTransportador(transportador);

                Pedido pedidoSalvo = pedidoRepository.save(pedidoAtualizado);
                return ResponseEntity.ok(pedidoSalvo);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // Transportador não encontrado
            }
        } else {
            return ResponseEntity.notFound().build(); // Pedido não encontrado
        }
    }
    
    @PutMapping("/remover-transportador/{id}")
    public ResponseEntity<?> removerTransportador(@PathVariable Integer id) {
        Optional<Pedido> pedidoOptional = pedidoRepository.findById(id);
        if (pedidoOptional.isPresent()) {
            Pedido pedido = pedidoOptional.get();
            pedido.setTransportador(null); // Define id_tr como null
            pedidoRepository.save(pedido);
            return ResponseEntity.ok("Transportador removido do pedido.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Pedido não encontrado.");
        }
    }

    // Método para deletar um pedido
    @DeleteMapping("/deletar/{id}")
    public ResponseEntity<Void> deletarPedido(@PathVariable Integer id) {
        Optional<Pedido> pedido = pedidoRepository.findById(id);
        if (pedido.isPresent()) {
            pedidoRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build(); // Retorna 404 se o pedido não for encontrado
        }
    }
}
