package br.com.confrete.confrete.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.confrete.confrete.DAO.IUsuariocl;
import br.com.confrete.confrete.model.UsuarioCl;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/usuariocl")
public class UsuarioControllerCl {

    @Autowired
    private IUsuariocl dao;

    @GetMapping("/{id}")
    public ResponseEntity<Optional<UsuarioCl>> acharUsuario(@PathVariable Integer id) {
        Optional<UsuarioCl> usuario = dao.findById(id);
        return usuario.isPresent() ? ResponseEntity.ok(usuario) : ResponseEntity.notFound().build();
    }

    @PostMapping("/login")
    public ResponseEntity<UsuarioCl> criarUsuario(@RequestBody UsuarioCl usuariocl) {
        try {
            System.out.println("Recebido: " + usuariocl.toString()); // Adicione um log aqui
            UsuarioCl usuarioNovo = dao.save(usuariocl);
            return ResponseEntity.ok(usuarioNovo);
        } catch (Exception e) {
            System.out.print(e);
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping
    public ResponseEntity<UsuarioCl> atualizarUsuario(@RequestBody UsuarioCl usuariocl) {
        try {
            UsuarioCl usuarioNovo = dao.save(usuariocl);
            return ResponseEntity.ok(usuarioNovo);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Optional<UsuarioCl>> excluirUsuario(@PathVariable Integer id) {
        Optional<UsuarioCl> usuario = dao.findById(id);
        if (usuario.isPresent()) {
            dao.deleteById(id);
            return ResponseEntity.ok(usuario);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
