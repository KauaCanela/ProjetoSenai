package br.com.confrete.confrete.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.confrete.confrete.DAO.ILoginCl;
import br.com.confrete.confrete.DAO.ILoginTr;
import br.com.confrete.confrete.model.Usuario;
import br.com.confrete.confrete.model.UsuarioCl;

@RestController
@CrossOrigin("*")
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private ILoginCl clienteDao;

    @Autowired
    private ILoginTr transportadorDao; // Adicionado

    // Método para autenticar cliente
    @PostMapping("/cliente")
    public ResponseEntity<UsuarioCl> autenticarCliente(@RequestBody UsuarioCl usuarioCl) {
        Optional<UsuarioCl> usuarioOpt = clienteDao.findByEmail(usuarioCl.getEmail());

        if (usuarioOpt.isPresent() && usuarioOpt.get().getSenha().equals(usuarioCl.getSenha())) {
            return ResponseEntity.ok(usuarioOpt.get());
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }

    // Método para autenticar transportador
    @PostMapping("/transportador")
    public ResponseEntity<Usuario> autenticarTransportador(@RequestBody Usuario usuario) {
        Optional<Usuario> usuarioOpt = transportadorDao.findByEmail(usuario.getEmail());

        if (usuarioOpt.isPresent() && usuarioOpt.get().getSenha().equals(usuario.getSenha())) {
            return ResponseEntity.ok(usuarioOpt.get());
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }
}