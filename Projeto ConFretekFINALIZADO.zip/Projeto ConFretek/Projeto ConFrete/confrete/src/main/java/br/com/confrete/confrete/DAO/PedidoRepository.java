package br.com.confrete.confrete.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.confrete.confrete.model.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Integer> {

    // Busca pedidos por ID do cliente
    List<Pedido> findByClienteId(Integer idCliente);

    // Busca pedidos pelo ID do transportador (se o nome da chave for transportadorId no modelo Pedido)
    List<Pedido> findByTransportadorId(Integer idTransportador);

    // Método para listar pedidos sem transportador (transportador null)
    List<Pedido> findByTransportadorIsNull();
    
    
    
    
}
