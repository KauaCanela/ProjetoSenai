package br.com.confrete.confrete.DAO;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.confrete.confrete.model.Pedido;
import br.com.confrete.confrete.model.Usuario;

@Repository
public interface IPedido extends JpaRepository<Pedido, Integer> {

}