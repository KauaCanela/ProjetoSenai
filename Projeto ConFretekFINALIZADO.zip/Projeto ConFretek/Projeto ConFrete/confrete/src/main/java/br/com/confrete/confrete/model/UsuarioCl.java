package br.com.confrete.confrete.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

@Entity
@Table(name = "login_cl")
public class UsuarioCl {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cl")
    private Integer id_cl;

    @Column(name = "username_cl", length = 50, nullable = false)
    private String username;

    @Column(name = "cpf_cl", length = 50, nullable = false, unique = true)
    private String cpf;

    @Column(name = "email_cl", length = 100, nullable = false, unique = true)
    private String email;

    @Column(name = "senha_cl", length = 150, nullable = false)
    private String senha;

    @Column(name = "telefone_cl", length = 50, nullable = false, unique = true)
    private String telefone;

    @Column(name = "data_cl", length = 30, nullable = true)
    private String dataNascimento;

    @Column(name = "cep_cl", length = 50, nullable = false)
    private String cep;

    @Column(name = "endereco_cl", length = 100, nullable = false)
    private String endereco;

    @Column(name = "numero_cl", length = 10, nullable = false)
    private String numero;

    @Column(name = "bairro_cl", length = 100, nullable = false)
    private String bairroCli;


    @Column(name = "cidade_cl", length = 50, nullable = false)
    private String cidade;

    @Column(name = "estado_cl", length = 20, nullable = false)
    private String estado;

    @Column(name = "classe_cl", length = 50, nullable = true)
    private String classe;

    @Lob
    @Column(name = "foto_cl")
    private byte[] fotoPerfil;

    // Getters e Setters
    public Integer getId() {
        return id_cl;
    }

    public void setId(Integer idCliente) {
        this.id_cl = idCliente;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairroCli;
    }

    public void setBairro(String bairro) {
        this.bairroCli = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getClasse() {
        return classe;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }

    public byte[] getFotoPerfil() {
        return fotoPerfil;
    }

    public void setFotoPerfil(byte[] fotoPerfil) {
        this.fotoPerfil = fotoPerfil;
    }
}
