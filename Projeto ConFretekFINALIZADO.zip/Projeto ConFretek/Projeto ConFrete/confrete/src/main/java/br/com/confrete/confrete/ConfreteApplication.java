package br.com.confrete.confrete;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfreteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfreteApplication.class, args);
	}

}
