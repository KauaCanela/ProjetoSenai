package br.com.confrete.confrete.model;

import java.sql.Timestamp;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "pedidos")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pedido")
    private Integer idPedido;

    @Column(name = "carga", length = 100, nullable = true)
    private String carga;

    @Column(name = "telefone", length = 20, nullable = false)
    private String telefone;

    @Column(name = "dt_saida", nullable = true)
    private LocalDate dataSaida;

    @Column(name = "dt_chegada", nullable = true)
    private LocalDate dataChegada;

    @Column(name = "dt_emissao", nullable = false, updatable = false, insertable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp dataEmissao;

    @Column(name = "cep_saida", length = 15, nullable = true)
    private String cepSaida;

    @Column(name = "cep_chegada", length = 15, nullable = true)
    private String cepChegada;

    @Column(name = "rua", length = 100, nullable = true)
    private String rua;

    @Column(name = "bairro", length = 100, nullable = true)
    private String bairro;

    @Column(name = "numero", length = 10, nullable = true)
    private String numero;

    @Column(name = "quilometragem", length = 100, nullable = true)
    private String quilometragem;

    @Column(name = "valor", length = 100, nullable = true)
    private String valor;
    
    @Column(name = "stt_pedido", length = 30, nullable = true)
    private String status;


    @ManyToOne 
    @JoinColumn(name = "id_cl")
    private UsuarioCl cliente;

    @ManyToOne
    @JoinColumn(name = "id_tr")
    private Usuario transportador;

    // Getters e Setters
    public Integer getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(Integer idPedido) {
        this.idPedido = idPedido;
    }

    public String getCarga() {
        return carga;
    }

    public void setCarga(String carga) {
        this.carga = carga;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public LocalDate getDataSaida() {
        return dataSaida;
    }

    public void setDataSaida(LocalDate dataSaida) {
        this.dataSaida = dataSaida;
    }

    public LocalDate getDataChegada() {
        return dataChegada;
    }

    public void setDataChegada(LocalDate dataChegada) {
        this.dataChegada = dataChegada;
    }

    public Timestamp getDataEmissao() {
        return dataEmissao;
    }

    public String getCepSaida() {
        return cepSaida;
    }

    public void setCepSaida(String cepSaida) {
        this.cepSaida = cepSaida;
    }

    public String getCepChegada() {
        return cepChegada;
    }

    public void setCepChegada(String cepChegada) {
        this.cepChegada = cepChegada;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getQuilometragem() {
        return quilometragem;
    }

    public void setQuilometragem(String quilometragem) {
        this.quilometragem = quilometragem;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public UsuarioCl getCliente() {
        return cliente;
    }

    public void setCliente(UsuarioCl cliente) {
        this.cliente = cliente;
    }

    public Usuario getTransportador() {
        return transportador;
    }

    public void setTransportador(Usuario transportador) {
        this.transportador = transportador;
    }
}
