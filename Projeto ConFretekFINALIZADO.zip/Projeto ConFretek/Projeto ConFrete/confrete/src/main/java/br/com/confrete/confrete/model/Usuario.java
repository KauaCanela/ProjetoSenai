package br.com.confrete.confrete.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "login_tr")
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tr")
    private Integer id;

    @Column(name = "username_tr", length = 50, nullable = true)
    private String username;

    @Column(name = "cpf_tr", length = 11, nullable = true, unique = true)
    private String cpf;

    @Column(name = "email_tr", length = 100, nullable = true, unique = true)
    private String email;

    @Column(name = "senha_tr", length = 150, nullable = true)
    private String senha;

    @Column(name = "telefone_tr", length = 50, nullable = false, unique = true)
    private String telefone;

    @Column(name = "data_tr", length = 50, nullable = true)
    private String data;

    @Column(name = "cep_tr", length = 50, nullable = true)
    private String cep;

    @Column(name = "endereco_tr", length = 100, nullable = true)
    private String endereco;

    @Column(name = "numero_tr", length = 10, nullable = true)
    private String numero;

    @Column(name = "bairro_tr", length = 100, nullable = true)
    private String bairro;

    @Column(name = "cidade_tr", length = 100, nullable = true)
    private String cidade;

    @Column(name = "estado_tr", length = 20, nullable = true)
    private String estado;

    @Column(name = "classe_tr", length = 50, nullable = false)
    private String classe;

    @Column(name = "foto_tr", nullable = true)
    private byte[] foto;

    // Getters e Setters

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getClasse() {
        return classe;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }

    public byte[] getFoto() {
        return foto;
    }

    public void setFoto(byte[] foto) {
        this.foto = foto;
    }
}
