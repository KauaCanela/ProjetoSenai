package br.com.confrete.confrete.DAO;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import br.com.confrete.confrete.model.UsuarioCl;

public interface IUsuariocl extends JpaRepository<UsuarioCl, Integer> {
    Optional<UsuarioCl> findByEmail(String email) ;
}
