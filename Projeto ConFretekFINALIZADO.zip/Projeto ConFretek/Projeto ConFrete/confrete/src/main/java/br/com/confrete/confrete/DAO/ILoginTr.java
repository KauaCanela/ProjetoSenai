package br.com.confrete.confrete.DAO;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import br.com.confrete.confrete.model.Usuario;

public interface ILoginTr extends JpaRepository<Usuario, Integer> {
    Optional<Usuario> findByEmail(String email);
}