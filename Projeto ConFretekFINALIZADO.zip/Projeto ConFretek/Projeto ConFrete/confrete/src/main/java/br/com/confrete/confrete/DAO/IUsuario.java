package br.com.confrete.confrete.DAO;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.confrete.confrete.model.Usuario;

@Repository
public interface IUsuario extends JpaRepository<Usuario, Integer> {

    Optional<Usuario> findById(Integer id); // Este método já está configurado
}
