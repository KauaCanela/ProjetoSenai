package br.com.confrete.confrete.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.confrete.confrete.DAO.IUsuario;
import br.com.confrete.confrete.model.Usuario;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/usuario")
public class UsuarioController {

    @Autowired
    private IUsuario dao;

    // Endpoint para buscar usuário pelo ID
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> acharUsuario(@PathVariable Integer id) {
        Optional<Usuario> usuario = dao.findById(id);
        if (usuario.isPresent()) {
            return ResponseEntity.ok(usuario.get()); // Retorna o usuário
        } else {
            return ResponseEntity.notFound().build(); // Caso não encontre o usuário
        }
    }

    // Endpoint para criar um novo usuário
    @PostMapping("/logtr")
    public ResponseEntity<?> criarUsuario(@RequestBody Usuario usuario) {
        try {
            // Verifica se o usuário já existe antes de salvar
            Usuario usuarioNovo = dao.save(usuario);
            return ResponseEntity.ok(usuarioNovo);
        } catch (DataIntegrityViolationException e) {
            // Caso haja violação de integridade (como duplicidade)
            String errorMessage = "Erro: O valor inserido já existe em outro registro. Verifique os campos únicos (username, cpf, email, telefone).";
            return ResponseEntity.status(409).body(errorMessage);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erro ao criar o usuário.");
        }
    }

    // Endpoint para atualizar dados de um usuário existente
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> atualizarUsuario(@PathVariable Integer id, @RequestBody Usuario usuario) {
        try {
            Optional<Usuario> usuarioExistente = dao.findById(id);
            if (usuarioExistente.isPresent()) {
                usuario.setId(id); // Garante que o ID do usuário está presente para atualização
                Usuario usuarioNovo = dao.save(usuario);
                return ResponseEntity.ok(usuarioNovo);
            } else {
                return ResponseEntity.notFound().build(); // Se o usuário não for encontrado
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    // Endpoint para excluir um usuário
    @DeleteMapping("/{id}")
    public ResponseEntity<Optional<Usuario>> excluirUsuario(@PathVariable Integer id) {
        Optional<Usuario> usuario = dao.findById(id);
        if (usuario.isPresent()) {
            dao.deleteById(id); // Deleta o usuário
            return ResponseEntity.ok(usuario);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
